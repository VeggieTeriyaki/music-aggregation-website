// cpanel - site_templates/countdown_tech/assets/config.js.tt Copyright(c) 2016 cPanel, Inc.
//                                                          All rights Reserved.
// copyright@cpanel.net                                        http://cpanel.net
// This code is subject to the cPanel license. Unauthorized copying is prohibited

window.cpanel = {
    data: {
        email: "",
        logo: "Smalldata",
        social: [
            
            
            
            
            
            
        ]
    },
    style: {
        primary: "",
    },
    slides: [
        {
            type: 'countdown',
            backgroundImage: "https:\/\/www.google.com\/url?sa=i&source=images&cd=&ved=2ahUKEwi9ypXHlYzeAhUR3lMKHW4hCcYQjRx6BAgBEAU&url=https%3A%2F%2Fdancingastronaut.com%2F2017%2F04%2Fglobal-music-report-shows-rise-music-streaming%2F&psig=AOvVaw2Hn7ie2xchWGQAZBimvODb&ust=1539820772097797",
            backgroundColor: "",
            color: "",
            buttonText: "",
            buttonLink: "",
            endTime: '2018-11-28T18:00:00.000Z'
        }
    ]
};
