// cpanel - site_templates/countdown_tech/assets/config.js.tt Copyright(c) 2016 cPanel, Inc.
//                                                          All rights Reserved.
// copyright@cpanel.net                                        http://cpanel.net
// This code is subject to the cPanel license. Unauthorized copying is prohibited

window.cpanel = {
    data: {
        email: "",
        logo: "Smalldata",
        social: [
            
            
            
            
            
            
        ]
    },
    style: {
        primary: "",
    },
    slides: [
        {
            type: 'countdown',
            backgroundImage: "C:\/Users\/Sahil Shah\/Downloads\/streaming-graphic.jpg",
            backgroundColor: "",
            color: "",
            buttonText: "",
            buttonLink: "",
            endTime: '2018-11-28T18:00:00.000Z'
        }
    ]
};
